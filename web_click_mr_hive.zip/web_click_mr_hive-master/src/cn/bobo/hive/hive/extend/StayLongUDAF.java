package cn.bobo.hive.hive.extend;

import org.apache.hadoop.hive.ql.exec.UDAF;
import org.apache.hadoop.hive.ql.exec.UDF;


public class StayLongUDAF extends UDAF{

}
