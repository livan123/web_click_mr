package cn.bobo.hive.annolog.distjh;


/**
 * Created by bobo on 2017/6/5.
 */
public class SingleTest {
    private class Sin{
         Sin getSin(){
            return new Sin();
        }
    }
}
